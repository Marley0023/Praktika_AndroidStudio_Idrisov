package adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.pr2_idrisov.databinding.MovieItemBinding
import models.movie
import android.webkit.WebView
import android.webkit.WebViewClient


class MovieAdapter(private val onMovieClickListener: OnMovieClickListener): RecyclerView.Adapter<MovieAdapter.ViewHolder>() {

    interface OnMovieClickListener {
        fun onMovieClick(movie: movie)
    }

    private var selectedPosition: Int = -1
    private var selectedMovie: movie? = null
    private var items: List<movie> = emptyList()

    companion object Factory {
        fun create(onMovieClickListener: OnMovieClickListener): MovieAdapter {
            return MovieAdapter(onMovieClickListener)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            MovieItemBinding.inflate(
                LayoutInflater.from(parent.context), parent, false
            )
        )
    }

    fun getItems(): List<movie> {
        return items
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.tvMovieName.text = item.movie
        holder.tvMovieStar.text = item.rating.toString()
        holder.itemView.setOnClickListener {
            onMovieClickListener.onMovieClick(item)
        }
    }

    override fun getItemCount(): Int {
        return items.size
    }

    fun getSelectedMovie(): movie? {
        return selectedMovie
    }

    class ViewHolder(binding: MovieItemBinding) : RecyclerView.ViewHolder(binding.root) {
        val tvMovieName = binding.movieName
        val tvMovieStar = binding.movieStar
    }

    fun refreshMovies(newItems: List<movie>) {
        this.items = newItems
        notifyDataSetChanged()
    }

    fun sortByRating() {
        val sortedMovies = items.sortedByDescending { it.rating.toFloatOrNull() ?: 0f }
        refreshMovies(sortedMovies)
    }
}

fun RecyclerView.setupMoviesAdapter(onMovieClickListener: MovieAdapter.OnMovieClickListener) {
    val adapter = MovieAdapter.create(onMovieClickListener)
    this.adapter = adapter
}