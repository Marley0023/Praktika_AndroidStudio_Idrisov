package adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.pr2_idrisov.databinding.ProductItemBinding
import models.product

class ProductAdapter(): RecyclerView.Adapter<ProductAdapter.ViewHolder>() {
    private var selectedPosition: Int = -1
    private var selectedCourier: product? = null
    private lateinit var items: List<product>
    companion object Factory {
        fun create(): ProductAdapter {
            return ProductAdapter()
        }
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            ProductItemBinding.inflate(
                LayoutInflater.from(parent.context), parent, false
            )
        )
    }
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.tvProductName.text = item.name
        holder.itemView.isSelected = selectedPosition == holder.layoutPosition }
    override fun getItemCount(): Int {
        return items.size
    }
    fun getSelectedCourier(): product? {
        return selectedCourier
    }
    class ViewHolder(binding: ProductItemBinding) : RecyclerView.ViewHolder(binding.root) {
        val tvProductName = binding.productName
    }
    fun refreshCouriers(items: List<product>) {
        this.items = items
    }
}