package models

import kotlinx.serialization.Serializable

class movie(val id: Int, val movie: String, val rating: String, val image: String, val imdb_url: String) :
    java.io.Serializable