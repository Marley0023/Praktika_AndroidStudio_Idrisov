package models

class product(val id: Int, val name: String)
