package database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "MyData")
data class MyData(
    @PrimaryKey(autoGenerate = true) val PrimaryKey: Int,
    @ColumnInfo(name = "name") val name: String,
    @ColumnInfo(name = "surname") val surname: String,
    @ColumnInfo(name = "group") val group: String,
    @ColumnInfo(name = "image") val image: ByteArray
)

