package com.example.pr2_idrisov.ui.home

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import database.MyData
import database.MyDataBase
import interfaces.MyDataBaseDao
import retrofit2.http.Url
import android.view.View.OnClickListener
import androidx.core.content.FileProvider
import com.example.pr2_idrisov.databinding.FragmentHomeBinding
import java.io.ByteArrayOutputStream
import java.io.File

class HomeFragment : Fragment() {

    private lateinit var binding: FragmentHomeBinding
    private lateinit var db: MyDataBase
    private lateinit var context: Context
    private lateinit var imageV: ImageView
    private lateinit var imageUri: Uri

    private var lastName: String? = null
    private var lastSurname: String? = null
    private var lastGroup: String? = null
    private var lastImage: ByteArray? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentHomeBinding.inflate(inflater, container, false)
        db = MyDataBase.getInstance(requireContext())
        val root: View = binding.root
        val homeViewModel =
            ViewModelProvider(this).get(HomeViewModel::class.java)
        imageV = binding.imageV
        imageUri = createImageUri()
        val contract = registerForActivityResult(ActivityResultContracts.TakePicture())
        {
            if (it) {
                imageV.setImageURI(imageUri)
            }
        }
        imageV.setOnClickListener{
            contract.launch(imageUri)
        }

        binding.but.setOnClickListener {
            val name = binding.name.text.toString()
            val surname = binding.surname.text.toString()
            val group = binding.group.text.toString()
            val imageBytes = convertImageToBytes(imageV)
            if (name.isNotEmpty() && surname.isNotEmpty() && group.isNotEmpty()) {
                val data = MyData(0, name, surname, group, imageBytes)
                Thread {
                    db.getDbDao().insert(data)
                    activity?.runOnUiThread {
                        Toast.makeText(context, "Data saved", Toast.LENGTH_SHORT).show()
                    }
                }.start()
            } else {
                Toast.makeText(context, ".", Toast.LENGTH_SHORT).show()
            }
        }

        Thread {
            val lastData = db.getDbDao().getLastData()
            activity?.runOnUiThread {
                lastName = lastData?.name
                lastSurname = lastData?.surname
                lastGroup = lastData?.group
                lastImage = lastData?.image

                binding.name.setText(lastName)
                binding.surname.setText(lastSurname)
                binding.group.setText(lastGroup)
                if (lastImage != null) {
                    val bitmap = BitmapFactory.decodeByteArray(lastImage, 0, lastImage!!.size)
                    imageV.setImageBitmap(bitmap)
                }
            }
        }.start()

        return root
    }

    private fun convertImageToBytes(image: ImageView): ByteArray {
        val bitmap = (image.drawable as BitmapDrawable).bitmap
        val scaledBitmap = resizeBitmap(bitmap, 300)
        val stream = ByteArrayOutputStream()
        scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 80, stream)
        val byteArray = stream.toByteArray()
        return byteArray
    }

    private fun createImageUri(): Uri {
        val image = File(requireActivity().filesDir, "myPhoto.png")
        return FileProvider.getUriForFile(
            requireContext(),
            "com.example.pr2_idrisov.FileProvider",
            image
        )
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        this.context = context
    }

    private fun resizeBitmap(bitmap: Bitmap, maxSize: Int): Bitmap {
        var width = bitmap.width
        var height = bitmap.height

        val bitmapRatio = width.toFloat() / height.toFloat()
        if (bitmapRatio > 1) {
            width = maxSize
            height = (width / bitmapRatio).toInt()
        } else {
            height = maxSize
            width = (height * bitmapRatio).toInt()
        }

        return Bitmap.createScaledBitmap(bitmap, width, height, true)
    }
}