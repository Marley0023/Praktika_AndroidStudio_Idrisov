package com.example.pr2_idrisov.ui.Movies

import adapters.MovieAdapter
import com.example.pr2_idrisov.R
import android.content.ContentValues.TAG
import android.content.Context
import android.graphics.Rect
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.SearchView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.pr2_idrisov.databinding.FragmentMovieBinding
import interfaces.IMovie
import models.movie
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MoviesFragment : Fragment() {

    private lateinit var binding: FragmentMovieBinding
    private lateinit var context: Context
    private lateinit var adapter: MovieAdapter
    private lateinit var searchView: SearchView
    private lateinit var viewModel: ViewModel
    private var moviesList = mutableListOf<movie>()
    private var filteredMoviesList = mutableListOf<movie>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        binding = FragmentMovieBinding.inflate(inflater, container, false)
        context = this.requireContext()
        binding.rvMovie.layoutManager = LinearLayoutManager(context)

        val itemDecoration = VerticalSpaceItemDecoration(16)
        binding.rvMovie.addItemDecoration(itemDecoration)

        adapter = MovieAdapter.create(object : MovieAdapter.OnMovieClickListener {

            override fun onMovieClick(movie: movie) {
                val bundle = Bundle().apply {
                    putString("url", movie.imdb_url)
                }
                findNavController().navigate(R.id.action_navigation_notifications_to_navigation_movie, bundle)
            }
        })

        searchView = binding.searchView
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                filter(newText)
                return false
            }
        })

        val moviesViewModel =
            ViewModelProvider(this).get(MoviesViewModel::class.java)
        val retrofit = Retrofit.Builder()
            .baseUrl("https://dummyapi.online/api/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val movieApi: IMovie = retrofit.create(IMovie::class.java)
        val call = movieApi.getMovies()

        call.enqueue(object  : Callback<List<movie>> {
            override fun onResponse(call: Call<List<movie>>, response: Response<List<movie>>) {
                if (response.isSuccessful) {
                    val movies = response.body()
                    if (movies != null) {
                        moviesList.clear()
                        filteredMoviesList.clear()
                        moviesList.addAll(movies)
                        filteredMoviesList.addAll(movies)
                        filteredMoviesList.sortByDescending { it.rating }
                        adapter.refreshMovies(filteredMoviesList)
                        binding.rvMovie.adapter = adapter
                        filter(searchView.query.toString())
                    }
                }
            }
            override fun onFailure(call: Call<List<movie>>, t: Throwable) {
                Log.e(TAG, "Ошибка сети: ${t.message}")
            }
        })

        return binding.root
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("а", searchView.query.toString())
    }

    override fun onViewStateRestored(savedInstanceState: Bundle?) {
        super.onViewStateRestored(savedInstanceState)
        if (savedInstanceState != null) {
            val searchQuery = savedInstanceState.getString("а")
            searchView.setQuery(searchQuery, false)
            filter(searchQuery)
        }
    }

    private fun filter(text: String?) {
        filteredMoviesList = moviesList.filter { movie ->
            text.isNullOrEmpty() || movie.movie.contains(text, ignoreCase = true)
        }.sortedByDescending { it.rating }.toMutableList()
        adapter.refreshMovies(filteredMoviesList)
    }
}

class VerticalSpaceItemDecoration(private val verticalSpaceHeight: Int) : RecyclerView.ItemDecoration() {
    override fun getItemOffsets(outRect: Rect, view: View, parent: RecyclerView, state: RecyclerView.State) {
        outRect.bottom = verticalSpaceHeight
    }
}