package com.example.pr2_idrisov.ui.webView

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import com.example.pr2_idrisov.databinding.FragmentWebViewBinding

class WebViewMovie : Fragment() {

    private lateinit var binding: FragmentWebViewBinding
    private lateinit var webView: WebView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentWebViewBinding.inflate(inflater, container, false)
        webView = binding.wvMovie
        val url = arguments?.getString("url")
        if (url != null) {
            webView.webViewClient = WebViewClient()
            webView.loadUrl(url)
        }
        return binding.root
    }
}