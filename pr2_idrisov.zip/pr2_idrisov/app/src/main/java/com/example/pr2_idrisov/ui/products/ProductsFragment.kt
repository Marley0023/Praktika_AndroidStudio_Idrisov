package com.example.pr2_idrisov.ui.products

import adapters.ProductAdapter
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.pr2_idrisov.databinding.FragmentProductsBinding
import models.product

class ProductsFragment : Fragment() {

    private lateinit var binding: FragmentProductsBinding
    private lateinit var products: List<product>
    private lateinit var context: Context
    private lateinit var adapter: ProductAdapter
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentProductsBinding.inflate(inflater, container, false)
        context = this.requireContext()
        binding.rvProducts.layoutManager = LinearLayoutManager(context)
        adapter = ProductAdapter.create()
        val productsViewModel =
            ViewModelProvider(this).get(ProductsViewModel::class.java)
        products = listOf(
            product(1, "Молоко"),
            product(2, "Яйца"),
            product(3, "Хлеб"),
            product(4, "Яблоки"),
            product(5, "Груши"),
            product(6, "Имбирь"),
            product(7, "Лимон"),
            product(8, "Виноград"),
            product(9, "Кексы"),
            product(10, "Шоколад")
        )
        adapter.refreshCouriers(products)
        binding.rvProducts.adapter = adapter
        return binding.root
    }
}