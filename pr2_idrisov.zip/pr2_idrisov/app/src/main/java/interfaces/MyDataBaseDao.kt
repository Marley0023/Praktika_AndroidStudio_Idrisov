package interfaces

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import database.MyData
import kotlinx.coroutines.flow.Flow

@Dao
interface MyDataBaseDao {
    @Insert
    fun insert(vararg users: MyData)

    @Update
    fun update(users: MyData)

    @Query("SELECT * FROM MyData")
    fun get(): Flow<List<MyData>>

    @Query("DELETE FROM MyData")
    fun deleteAll()
    @Query("SELECT * FROM MyData ORDER BY PrimaryKey DESC LIMIT 1")
    fun getLastData(): MyData?

}