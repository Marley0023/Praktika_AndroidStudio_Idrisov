package interfaces

import models.movie
import retrofit2.Call
import retrofit2.http.GET

interface IMovie {
    @GET("movies")
    fun getMovies(): Call<List<movie>>
}